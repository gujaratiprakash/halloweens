<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST'); 
include('config.php');

$data = array();

$sql="SELECT DISTINCT(station_name) FROM `routes` ORDER BY `station_name` ASC";

$result = mysqli_query($con,$sql)or die('query not fire');
 While($res=mysqli_fetch_array($result))
{

	$temp['route_title'] =$res['station_name'];

	$blank_arr[] = $temp;
	$data['station'] = $blank_arr;
}
echo json_encode($data);
mysqli_close($con);
?>
