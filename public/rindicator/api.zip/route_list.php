<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST'); 
include('config.php');

$data = array();

$sql="select * from route_list order by routeno ASC";

$result = mysqli_query($con,$sql)or die('query not fire');
 While($res=mysqli_fetch_array($result))
{
	$temp['id'] =$res['id'];
	$temp['routeno'] =$res['routeno'];
	$temp['route_title'] =$res['route_title'];
	$temp['route_type'] =$res['way_type'];

	$blank_arr[] = $temp;
	$data['route_list'] = $blank_arr;
}
echo json_encode($data);
mysqli_close($con);
?>
