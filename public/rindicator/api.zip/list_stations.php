<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST'); 
include('config.php');

$data = array();

$sql="select * from routes where routeno = '".$_GET['routeno']."' and way_type='".$_GET['route_type']."' order by id ASC";
$id = 0;
$result = mysqli_query($con,$sql)or die('query not fire');
 While($res=mysqli_fetch_array($result))
{
	$temp['id'] =$id++;
	$temp['routeno'] =$res['routeno'];
	$temp['route_title'] =$res['station_name'];
	$temp['route_type'] =$res['way_type'];

	$blank_arr[] = $temp;
	$data['stations_list'] = $blank_arr;
}
echo json_encode($data);
mysqli_close($con);
?>
