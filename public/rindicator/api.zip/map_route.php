<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST'); 
include('config.php');

$data = array();

$sql="select * from map_routes where routeno = '".$_GET['routeno']."' and way_type='".$_GET['route_type']."' order by id ASC";

$result = mysqli_query($con,$sql)or die('query not fire');
 While($res=mysqli_fetch_array($result))
{
	$temp['id'] =$res['id'];
	$temp['BoxId'] =$res['BoxId'];
	$temp['RouteNo'] =$res['RouteNo'];
	$temp['Busno'] =$res['Busno'];
	$temp['VehName'] =$res['VehName'];
	$blank_arr[] = $temp;
	$data['map_routes'] = $blank_arr;
}
echo json_encode($data);
mysqli_close($con);
?>
