<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST'); 
include('config.php');

//date_default_timezone_set('Asia/Kolkata');
$source = $_GET['source'];
$destination = $_GET['destination'];
//$starttime = date('12:00:00');
$starttime = date('H:i:s');

$user = array();
	
$sql="SELECT s1.name as route_1_name,
    s1.route_no as route_1,
    m_stations.name as via,
    s2.name as route_2_name,
    s2.route_no as route_2,
    max(s1.time) as via_arrival,
    max(s2.time) as via_departure,
    (s2.time - s1.time) / 100 AS waiting_time
FROM
(SELECT s.station_id,s.route_id,r.route_no,r.name,s.time FROM m_schedule s
JOIN m_routes r ON s.route_id = r.id
WHERE r.route_no IN (SELECT DISTINCT(m_routes.route_no) FROM m_schedule
LEFT JOIN m_stations ON m_schedule.station_id = m_stations.id
JOIN m_routes ON m_schedule.route_id = m_routes.id
WHERE m_stations.id = (SELECT id FROM m_stations WHERE name = '$source' LIMIT 1)) ORDER BY s.time ASC) AS s1
JOIN
(SELECT s.station_id,s.route_id,r.route_no,r.name,s.time FROM m_schedule s
JOIN m_routes r ON s.route_id = r.id
WHERE r.route_no IN (SELECT DISTINCT(m_routes.route_no) FROM m_schedule
LEFT JOIN m_stations ON m_schedule.station_id = m_stations.id
JOIN m_routes ON m_schedule.route_id = m_routes.id
WHERE m_stations.id = (SELECT id FROM m_stations WHERE name = '$destination' LIMIT 1)) ORDER BY s.time ASC) AS s2
ON s1.station_id = s2.station_id
AND s1.time < s2.time AND s1.time + INTERVAL 15 MINUTE > s2.time
JOIN m_stations ON s1.station_id = m_stations.id OR s2.station_id = m_stations.id
GROUP BY route_1
ORDER BY waiting_time ASC";

$result = mysqli_query($con,$sql)or die('query not fire');


while($res=mysqli_fetch_array($result))
{

	$temp['route_1_name'] =$res['route_1_name'];
	$temp['route_1'] =$res['route_1'];
	$temp['route_2_name'] =$res['route_2_name'];
	$temp['route_2'] =$res['route_2'];
	$temp['via'] = $res['via'];
	$temp['waiting_time'] = (int) $res['waiting_time'];
	$blank_arr[] = $temp;
	$user['BusViaSearchFragmentModel'] = $blank_arr;
}
/*
if(empty($res))
{
    $temp['id'] ="-1";
	$blank_arr[] = $temp;
	$user['busViaSearchFragmentModel'] = $blank_arr;
}*/
echo json_encode($user);
mysqli_close($con);
?>
