<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST'); 
include('config.php');

//date_default_timezone_set('Asia/Kolkata');
$source = $_GET['source'];
$destination = $_GET['destination'];
//$starttime = date('12:00:00');
$starttime = date('H:i:s');

$user = array();
	
$sql="SELECT s1.name as route_1_name,
    s1.route_no as route_1,
    m_stations.name as via,
    s2.name as route_2_name,
    s2.route_no as route_2,
    max(s1.time) as via_arrival,
    max(s2.time) as via_departure,
    (s2.time - s1.time) / 100 AS waiting_time
FROM
(SELECT s.station_id,s.route_id,r.route_no,r.name,s.time FROM m_schedule s
JOIN m_routes r ON s.route_id = r.id
WHERE r.route_no IN (SELECT DISTINCT(m_routes.route_no) FROM m_schedule
LEFT JOIN m_stations ON m_schedule.station_id = m_stations.id
JOIN m_routes ON m_schedule.route_id = m_routes.id
WHERE m_stations.id = (SELECT id FROM m_stations WHERE name = '$source' LIMIT 1)) ORDER BY s.time ASC) AS s1
JOIN
(SELECT s.station_id,s.route_id,r.route_no,r.name,s.time FROM m_schedule s
JOIN m_routes r ON s.route_id = r.id
WHERE r.route_no IN (SELECT DISTINCT(m_routes.route_no) FROM m_schedule
LEFT JOIN m_stations ON m_schedule.station_id = m_stations.id
JOIN m_routes ON m_schedule.route_id = m_routes.id
WHERE m_stations.id = (SELECT id FROM m_stations WHERE name = '$destination' LIMIT 1)) ORDER BY s.time ASC) AS s2
ON s1.station_id = s2.station_id
AND s1.time < s2.time AND s1.time + INTERVAL 15 MINUTE > s2.time
JOIN m_stations ON s1.station_id = m_stations.id OR s2.station_id = m_stations.id
GROUP BY route_1
ORDER BY waiting_time ASC";

$result = mysqli_query($con,$sql)or die('query not fire');


while($res=mysqli_fetch_array($result))
{

    $durdis1 = GetStationsDurationDistance($con,$source,$res['via']);
    $durdis2 = GetStationsDurationDistance($con,$res['via'],$destination);
    
	$temp['route_1_name'] =$res['route_1_name'];
	$temp['route_1'] =$res['route_1'];
	$temp['route_2_name'] =$res['route_2_name'];
	$temp['route_2'] =$res['route_2'];
	$temp['via'] = $res['via'];
	$temp['waiting_time'] = (int) $res['waiting_time'];
	$temp['duration1'] = $durdis1['time'];  
	$temp['distance1'] =$durdis1['distance'];
	$temp['duration2'] = $durdis2['time'];  
	$temp['distance2'] =$durdis2['distance'];
	$blank_arr[] = $temp;
	$user['BusViaSearchFragmentModel'] = $blank_arr;
}
/*
if(empty($res))
{
    $temp['id'] ="-1";
	$blank_arr[] = $temp;
	$user['busViaSearchFragmentModel'] = $blank_arr;
}*/
echo json_encode($user);
mysqli_close($con);

function GetStationsDurationDistance($con,$s1,$s2)
{
    $sourcedestinationQuery = "SELECT * FROM `poi_list` WHERE `name` LIKE '%".$s1."%' OR `name` LIKE '%".$s2."%' limit 2";
    $sourcedestinationresult = mysqli_query($con,$sourcedestinationQuery)or die('query not fire');
    $sourcedestinationrowcount=mysqli_num_rows($sourcedestinationresult);
    $latlon1 = "";
    $latlon2 = "";
    $cn = 0;
    while($sourcedestinationRow=mysqli_fetch_row($sourcedestinationresult))
    {
        $cn++;
        if($cn==1)
        {$latlon1 = $sourcedestinationRow[2].",".$sourcedestinationRow[3];}
        if($cn==2)
        {$latlon2 = $sourcedestinationRow[2].",".$sourcedestinationRow[3];}
    }
    
    if($sourcedestinationrowcount>0)
    {
        return $durdis = GetDrivingDistance($latlon1,$latlon2);
        
    }else
    {
        return $durdis = array('distance' => "10 mi", 'time' => "15 mins");
    }
}



function GetDrivingDistance($latlon1,$latlon2)
{
    
    $url = "https://maps.googleapis.com/maps/api/distancematrix/json?units=imperial&origins=".$latlon1."&destinations=".$latlon2."&key=AIzaSyCb8OfRlOWXmBWuyQ6jXSBvVCWIg88ap2c&callback=initMap";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_PROXYPORT, 3128);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
     $response = curl_exec($ch);
    curl_close($ch);
    $response_a = json_decode($response, true);
    $dist = $response_a['rows'][0]['elements'][0]['distance']['text'];
    $time = $response_a['rows'][0]['elements'][0]['duration']['text'];

    return array('distance' => $dist, 'time' => $time);
}
?>
