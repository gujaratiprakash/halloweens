<?php
$con=mysqli_connect("localhost","stepinjob_pg","@]fDSl}Ch]M@97","stepinjob_location");
// Check connection
if(mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
  
?>